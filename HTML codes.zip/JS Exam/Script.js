function year(){
	var birthyear = prompt('What is your birthyear?');
	var AgeInDays = (2020 - birthyear) * 365;
	var h1 = document.createElement('h1');
	var textAnswer = document.createTextNode('You are ' + AgeInDays + ' days old');
	h1.setAttribute('id' , 'AgeInDays');
	h1.appendChild(textAnswer);
	document.getElementById('flex-box-result').appendChild(h1);
}

function reset(){
	document.getElementById('AgeInDays').remove();
}

function generateCat(){
	var image = document.createElement('img');
	var div = document.getElementById('flex-cat-gen');
	image.src = "cat.jpg";
	div.appendChild(image);
}	

