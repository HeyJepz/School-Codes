function show1() { //function about button
    document.getElementById('operation1').style.display = "block";
    document.getElementById('operation2').style.display = "none";
	
}

function show2() { //function program button
    document.getElementById('operation2').style.display = "block";
    document.getElementById('operation1').style.display = "none";
}
function year(){
	var birthyear = document.getElementById('Input').value; //variables
	var AgeInDays = (2020 - birthyear) * 365; //operators
	var h1 = document.createElement('h1');
	var textAnswer = document.createTextNode('You are ' + AgeInDays + ' days old');
	h1.setAttribute('id' , 'AgeInDays');
	h1.appendChild(textAnswer);
	document.getElementById('flex-box-result').appendChild(h1);
}

var input = document.getElementById("Input");
input.addEventListener("keyup", function(event) {
  if (event.keyCode === 13) { // Conditionals
   event.preventDefault();
   document.getElementById("Cal").click();
  }
});

function reset(){
	document.getElementById('AgeInDays').remove(); 
}	